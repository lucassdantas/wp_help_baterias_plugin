<?php 
//silence is golden